import os
print("DeepSeek key =", os.getenv("DEEPSEEK_API_KEY"))
